# PNA Finder

This is a toolbox for identifying antisense sequences for peptide nucleic acids.
You can find the manual for the PNA Finder toolbox [here](https://www.colorado.edu/lab/chatterjeelab/)